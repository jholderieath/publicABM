#' @rdname WildPigABM
#' @export
initialGlobalVariable <-
  function(allowableOverCap,
           boarTerritoryDecay,
           brange,
           dam_Corn,
           dam_soy,
           defaultLitter,
           discount,
           generic_removal_price,
           Govt_ON,
           init_hh,
           init_pigs,
           max_cycles,
           max_pigs,
           maxSounderN,
           minSounderN,
           outlook,
           sexRatio,
           SounderterritoryDecay,
           srange,
           total_patches,
           typeDecision,
           verboseR ,
           ...) {
    globalsDf <- data.frame(
      #gather input to push to NL as Dataframe
      allowableOverCap,
      boarTerritoryDecay,
      brange,
      dam_Corn,
      dam_soy,
      defaultLitter,
      discount,
      generic_removal_price,
      Govt_ON,
      init_hh,
      init_pigs,
      max_cycles,
      max_pigs,
      maxSounderN,
      minSounderN,
      outlook,
      sexRatio,
      SounderterritoryDecay,
      srange,
      total_patches,
      typeDecision
    )
    RNetLogo::NLDfToList(globalsDf)
    if (verboseR == TRUE) {
      print("globals dataframe pushed to NL!")
    }
    return(globalsDf)
  }