#' Feral Swine ABM Package
#'
#' An implementation of the Feral Swine Agent-Based Model
#' @keywords wild pigs
#' @rdname WildPigABM
#' @export
masterSchedule <- function(allowableOverCap, boarTerritoryDecay, 
  brange, dam_Corn, dam_CRP, dam_soy, defaultLitter, dirc, 
  Govt_ON, gui, init_hh, init_pigs, init_sounder, map_height, 
  map_width, max_cycles, max_pigs, maxSounderN, mergeAccelerator, 
  mergedistance, minPigsFee, minSounderN, model.path, nl.path, 
  P_corn, P_CRP, P_soy, patchSize, pig_range, sexRatio, SounderterritoryDecay, 
  splitAccelerator, srange, varCost_corn, varCost_soy, verboseR, 
  verCost_CRP, Yield_corn, Yield_soy, generic_removal_price, 
  typeDecision, realistic, discount, seed, RemovalPriceMethod, 
  UserCostMethod, bounty, cdecay, ...) {
  set.seed(seed, kind = NULL, normal.kind = NULL)
  ## Initialize
  ## ----------------------------------------------------------------------------------------------
  ## Load damage, future marginal cost, and removal cost
  ## functions
  load("~/GitHub/Version 2/WildPigABM/R/dynamicSpline.rdata")
  load("~/GitHub/Version 2/WildPigABM/R/pctDam.rdata")
  load("~/GitHub/Version 2/WildPigABM/R/fun6.rdata")
  total_patches <- map_width * map_height
  #### Start the clock --------------------------
  ptm <- proc.time()  # uses system clock to define start time for sim
  now <- tNow(verboseR)  # uses system clock to define variable used in naming
  today <- Sys.Date()
  #### Start NetLogo ---------------------
  RNetLogo::NLStart(nl.path, gui)
  RNetLogo::NLLoadModel(model.path)
  # if (gui == TRUE){ readline(prompt='Press [enter] to
  # continue') }
  clearNL(verboseR)
  command <- paste("random-seed ", seed, sep = "")
  RNetLogo::NLCommand(command)
  ##### Generate and pass initial patch variables
  ##### 'quality','effect_comm','effect_free','effect_govt','effect_fee',
  ##### 'memory','patch_id','psi_lastPeriod'
  initialPatchVarArray <- generateAndPassPV(map_height, map_width, 
    total_patches)
  # gather input to push to NL as Dataframe
  globalsDf <- data.frame(allowableOverCap, boarTerritoryDecay, 
    brange, dam_Corn, dam_soy, defaultLitter, discount, generic_removal_price, 
    init_hh, init_pigs, init_sounder, max_cycles, max_pigs, 
    maxSounderN, minSounderN, sexRatio, SounderterritoryDecay, 
    srange, total_patches, varCost_corn, varCost_soy, P_CRP, 
    bounty, cdecay)
  RNetLogo::NLDfToList(globalsDf)
  if (verboseR == TRUE) {
    print("globals dataframe pushed to NL!")
  }
  ##### Run NetLogo Setup Script
  RNetLogo::NLCommand("setup")
  Sys.sleep(2)
  ## Create Result Space
  ## -------------------------------------------------------------------------------------
  qual <- RNetLogo::NLGetPatches(c("pxcor", "pycor", "quality"), 
    patchset = "patches", as.data.frame = TRUE)
  counts <- data.frame(endoftickPigCount = double(), sowCountSum = double(), 
    boarCountSum = double(), killedCountT = double())
  Sounder_position <- list()
  boar_position <- list()
  pigTerritoryStrength <- array(data = 0, c(map_height, map_width, 
    max_cycles))
  plan <- list()
  patchuse <- list()
  wealthi <- RNetLogo::NLGetAgentSet("wealthi", "households", 
    as.data.frame = TRUE)
  Sys.sleep(2)
  ## Prepare for Sim
  ## -----------------------------------------------------------------------------------------
  ## if (gui == TRUE){ readline(prompt='Press [enter] to
  ## continue') }
  
  if (RemovalPriceMethod == "random") {
    a <- c("marginal", "minus", "linear")
    removalPrFnVec <- sample(a, init_hh, replace = TRUE)
  }
  if (RemovalPriceMethod == "linear") {
    removalPrFnVec <- rep_len("linear", length.out = init_hh)
  }
  if (RemovalPriceMethod == "marginal") {
    removalPrFnVec <- rep_len("marginal", length.out = init_hh)
  }
  if (RemovalPriceMethod == "minus") {
    removalPrFnVec <- rep_len("minus", length.out = init_hh)
  }
  if (UserCostMethod == "random") {
    a <- c("myopic", "minus", "linear")
    userCostFnVec <- sample(a, init_hh, replace = TRUE)
  }
  if (UserCostMethod == "myopic") {
    userCostFnVec <- rep_len("myopic", length.out = init_hh)
  }
  if (UserCostMethod == "minus") {
    userCostFnVec <- rep_len("minus", length.out = init_hh)
  }
  if (UserCostMethod == "linear") {
    userCostFnVec <- rep_len("linear", length.out = init_hh)
  }
  
  
  ## Model Run Loop
  ## ------------------------------------------------------------------------------------------
  for (t in 1:max_cycles) {
    iterName <- setIterName(t, now, verboseR)
    ### Landowner Planning
    ### -------------------------------------------------------------------------------------
    ### plan[t] <- dynamicISH(verboseR, t, now, total_patches,
    ### map_height, map_width,patchSize, init_hh,EGM_offFarmV,
    ### P_corn,P_soy,P_CRP, varCost_corn, varCost_soy,verCost_CRP,
    ### allow,typeDecision, today)
    plan[t] <- RevisedDynamicISH(verboseR, t, now, today, 
      init_hh, P_corn, P_soy, P_CRP, varCost_corn, varCost_soy, 
      verCost_CRP, removalPrFnVec, userCostFnVec, typeDecision, 
      bounty, ...)
    
    if (verboseR == TRUE) {
      print(paste("optimization complete for period ", 
        t))
    }
    
    Sys.sleep(2)
    # if (gui == TRUE){ readline(prompt='Press [enter] to
    # continue') } Update FS CageynessFS Breed and Move
    # ------------------------------------------------------------------------------------
    RNetLogo::NLCommand("go-pigops")
    Sys.sleep(1)
    # if (gui == TRUE){ readline(prompt='Press [enter] to
    # continue') }
    RNetLogo::NLCommand("go-myopic-removal")
    Sys.sleep(2)
    # if (gui == TRUE){ readline(prompt='Press [enter] to
    # continue') } Calculate HH Income and
    # wealth--------------------------------------------------------------------------
    RNetLogo::NLCommand("go-wrap-up-myopic")
    Sys.sleep(2)
    # if (gui == TRUE){ readline(prompt='Press [enter] to
    # continue') } Inventories
    # --------------------------------------------------------------------------------------------
    patchuse[t] <- RNetLogo::NLGetPatches(c("pxcor", "pycor", 
      "pigTerritoryStrength", "a_corn_none", "a_corn_light", 
      "a_corn_heavy", "a_soy_none", "a_soy_light", "a_soy_heavy", 
      "a_crp_none", "a_crp_light", "a_crp_heavy"), patchset = "patches", 
      as.data.frame = TRUE)
    
    
    
    pigTerritoryStrength[, , t] <- RNetLogo::NLGetPatches("pigTerritoryStrength", 
      patchset = "patches", as.matrix = TRUE)
    Sys.sleep(0.1)
    EOTPC <- RNetLogo::NLReport("pigCountSum")
    sowCountSum <- RNetLogo::NLReport("sowCountSum")
    if (sowCountSum > 0) {
      Sounder_position[[t]] <- RNetLogo::NLGetAgentSet(c("who", 
        "xcor", "ycor", "age"), "sows", as.data.frame = TRUE)
    }
    boarCountSum <- RNetLogo::NLReport("boarCountSum")
    if (boarCountSum > 0) {
      boar_position[[t]] <- RNetLogo::NLGetAgentSet(c("who", 
        "xcor", "ycor", "age"), "boars", as.data.frame = TRUE)
    }
    KCT <- countDead(verboseR)
    count <- data.frame(endoftickPigCount = EOTPC, sowCountSum = sowCountSum, 
      boarCountSum = boarCountSum, killedCountT = KCT)
    counts <- rbind(counts, count)
    
    
    ### Tick----------------------------------------------------------------------------------------------------
    wealthi <- cbind(wealthi, RNetLogo::NLGetAgentSet("wealthi", 
      "households", as.data.frame = TRUE))
    
    
    RNetLogo::NLCommand("killTheDead")  #clean up, reset land
    Sys.sleep(2)
    if (verboseR == TRUE) {
      print("The dead have been killed!")
    }
    
    RNetLogo::NLCommand("tick")
    if (verboseR == TRUE) {
      print(paste("tick ", t))
    }
  }
  
  ### Save Results & Close out
  ### NL----------------------------------------------------
  counts$RemovalPriceMethod <- RemovalPriceMethod
  counts$UserCostMethod <- UserCostMethod
  counts$bounty <- bounty
  counts$cdecay <- cdecay
  counts$t <- 1:max_cycles
  
  names(wealthi) <- paste0("t", 0:max_cycles)
  wealthi$id <- 1:45
  wealthi <- reshape::melt(wealthi, id.vars = "id")
  wealthi$sim <- paste("sim", typeDecision, generic_removal_price, 
    realistic, sep = "_")
  
  mainDir <- "C:/Users/zejas/OneDrive - Colostate/DissertationTopics/ABM/Intermediate_output/"
  subDir <- format(today, format = "%Y%b%d")
  dirc <- paste(mainDir, subDir, "/", sep = "")
  dir.create(file.path(dirc), showWarnings = FALSE, recursive = FALSE)
  # exportview <- paste('export-view
  # '',mainDir,subDir,'sim_',now,'_end_map_export.png'', sep =
  # '') RNetLogo::NLCommand(exportview)
  RNetLogo::NLCommand("clear-all")
  RNetLogo::NLQuit()
  ptm2 <- proc.time()
  simTime <- ptm2 - ptm
  returnItems <- list(typeDecision = typeDecision, generic_removal_price = generic_removal_price, 
    realistic = realistic, RemovalPriceMethod = RemovalPriceMethod, 
    UserCostMethod = UserCostMethod, bounty = bounty, cdecay = cdecay, 
    sexRatio = sexRatio, simTime = simTime, sdMult = sdMult, 
    optimResult = plan, counts = counts, globalsDf = globalsDf, 
    boar_position = boar_position, Sounder_position = Sounder_position, 
    pigTerritoryStrength = pigTerritoryStrength, wealthi = wealthi, 
    patchuse = patchuse)
  
  nam <- paste(dirc, now, typeDecision, realistic, ".rdata", 
    sep = "")
  save(returnItems, file = nam)
  nam <- paste(dirc, now, typeDecision, realistic, "quality.csv", 
    sep = "")
  write.csv(qual, file = nam)
  return(returnItems)
}