#' Feral Swine ABM Package
#'
#' An implementation of the Feral Swine Agent-Based Model
#'
#' @keywords wild pigs
#' @rdname WildPigABM
#' @export
doOne <- function(typeDecision, generic_removal_price, realistic, 
  RemovalPriceMethod, UserCostMethod, bounty, sexRatio, cdecay, 
  data, gui, ...)
  {
  
  attach(data)
  if (realistic == FALSE)
  {
    P_CRP <- 1
    varCost_corn <- 1
    varCost_soy <- 1
  }
  
  
  masterSchedule(allowableOverCap, boarTerritoryDecay, brange, 
    dam_Corn, dam_CRP, dam_soy, defaultLitter, dirc = "C:/Users/zejas/Documents/GitHub/Version 2/WildPigABM/inst/examples/output", 
    Govt_ON = FALSE, gui, init_hh, init_pigs, init_sounder = 5, 
    map_height, map_width, max_cycles = 5, max_pigs, maxSounderN, 
    mergeAccelerator, mergedistance, minPigsFee, minSounderN, 
    model.path = system.file("data/FromR_1.0.nlogo", package = "WildPigABM"), 
    nl.path = "C:/Program Files/NetLogo 5.3.1/app", P_corn, 
    P_CRP = 50, P_soy, patchSize, pig_range, sexRatio, SounderterritoryDecay, 
    splitAccelerator, srange, varCost_corn, varCost_soy, 
    verboseR, verCost_CRP = 2.22e-16, Yield_corn = 1350, 
    Yield_soy = 450, generic_removal_price = 0, typeDecision, 
    realistic, discount = 0.05, seed = 28128868, RemovalPriceMethod, 
    UserCostMethod, bounty, cdecay)
}