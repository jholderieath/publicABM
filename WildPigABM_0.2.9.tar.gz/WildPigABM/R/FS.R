#' Feral Swine ABM Package
#'
#' An implementation of the Feral Swine Agent-Based Model
#'
#' @keywords wild pigs
#'
#'
### Simulation Functions =============================================================================
## Create Result Space Arrays---------------
#' @rdname WildPigABM
#' @export
mapArraySpace <- function(data,map_height,map_width,max_cycles,...){
  array(data, c(map_height, map_width, max_cycles))
}

#' @rdname WildPigABM
#' @export
indivArraySpace <- function(data, max_cycles,total_patches,...){
  array(data, c(1, max_cycles))
}

#is.installed()  detect packages
#' @keywords wild pigs
#' @examples \dontrun{is.installed("cplexAPI")}
#' @rdname WildPigABM
#' @export
is.installed <- function(mypkg) is.element(mypkg, installed.packages()[,1]) 

#' @rdname WildPigABM
#' @export
normalize <- function(x){(x-min(x) + 2.220e-15)/(max(x)-min(x) + 2.220e-15)}
# reportTime() - Report time --------------------------------
#' @rdname WildPigABM
#' @examples \dontrun{reportTime(verboseR=FALSE)}
#' @export
reportTime <- function(verboseR = FALSE, ptm, ...) {
  if (verboseR == TRUE){print(timestamp())}
  proc.time() - ptm
}
# Start timing the exercise-------------------
#' @rdname WildPigABM
#' @export
tPtm <- function(...) {
    proc.time
}

#' @rdname WildPigABM
#' @export
tNow <- function(verboseR = FALSE) {
  now <- Sys.time()
  now <- format(now, "%Y%m%d_%H%M%S_")
  if (verboseR == TRUE) {
    print(now)
  }
}
## setIterName() - sets a name for each iteration --------------------------------
#' @rdname WildPigABM
#' @examples \dontrun{setIterName(t,now,verboseR=FALSE)}
#' @export
setIterName <- function(t, now, verboseR = FALSE, ...) {
  iterName <- paste("iteration_", t, "_", now, sep = "")
  if (verboseR == TRUE){print(iterName)}
  return(iterName)
}


### General NL PUSH/PULL Functions ===================================================================
## Clear NL --------------------------------------------
#' @rdname WildPigABM
#' @export
clearNL <- function(verboseR,...){
  RNetLogo::NLCommand("clear-all")
  if (verboseR == TRUE){print("NL Cleared!")}
}
## NL_pushToMap() Push characteristic to map in NL----------------------------------------- 
#' @rdname WildPigABM
#' @export
NL_pushToMap <- function(NLcharacteristic,data,nl.obj = NULL, ...){
  RNetLogo::NLSetPatches(NLcharacteristic, data, nl.obj = NULL)
  if (verboseR == TRUE) {print("map data pushed to NL!")}
}

### Specific NL PUSH/PULL Calls ======================================================================
## setOwnership - Get Ownership from NL -----------------------------------------------
#' @rdname WildPigABM
setOwnership <- function(init_hh, total_patches,... ) {
  array(data =  repColrepRow::repRow((array(data = 
            RNetLogo::NLGetPatches("owner", as.vector = TRUE), c(1, total_patches))[,]), init_hh), c(init_hh, total_patches))
}


## countHouseholds() - Count households in NL and report back to R --------------------
#' @rdname WildPigABM
#' @examples \dontrun{countHouseholds()}
#' @export
countHouseholds <- function(){
  households <- RNetLogo::NLGetAgentSet("who", "households")
  return(households)
}

# countOtherWildlife - Count the otherwildlife if turned on------------------
#' @rdname WildPigABM
#' @export
countOtherWildlife <- function(map_height, map_width,...) {
  if (competingWildlife == TRUE){
    RNetLogo::NLCommand(
      "ask patches [
    set othercrittercount count othercritters-here
    ]"
    )# count patches with pigs etc
    array(data = RNetLogo::NLGetPatches("othercrittercount",
                                        as.data.frame = FALSE, as.matrix = TRUE), 
          c(map_height, map_width))
  }
}
## tick() - send tick command to NL ------------------------------
#' @rdname WildPigABM
tick <- function(verboseR, t,...) {
  RNetLogo::NLCommand("tick")
  if (verboseR == TRUE){print(paste("tick ", t))}
}

### Transformation Functions Run AFTER a NL CALL ====================================================
## setOwnerRow - After 'setOwnership' Set each row to binary----------------------------------------------------------------------
#if a patch is owned by owner represented by the row, it will equal 1, otherwise 0
#' @rdname WildPigABM
setOwnerRow <- function(data,num_choice,init_hh, total_patches,...){
  dat = data
  for (i in 1:init_hh)
  {
    dat[i,][which(dat[i,] != (i - 1))] = -1
    dat[i,][which(dat[i,] == (i - 1))] = -2
    dat[i,][which(dat[i,] == -1)] <- as.numeric(0)
    dat[i,][which(dat[i,] == -2)] <- as.numeric(1)
  }
  array(dat[,],c(init_hh, total_patches*num_choice))
}
## indexR - Make index for subset and replace operations around optimization---------------------------------------
## Set each row to binary, if a patch is owned by owner represented by the row, it will equal 1, otherwise 0
## column 1 for each year is for off farm work
#' @rdname WildPigABM
indexR <- function(data,num_choice,total_patches,multiYearLand){
  ones <- array(data=1,c(init_hh,1))
  dat <- cbind(ones,data)
  if (multiYearLand == FALSE) {
    cc <- array(dat[,],c(init_hh, (total_patches*num_choice)+1))
  }
  if (multiYearLand == TRUE) {
    cc <- array(dat[,],c(init_hh, ((total_patches*num_choice)+1)*2))
  }
  return(cc)
}
### Optimization Prep, Optimization, & Income Functions ===================================================
## Gross Margin Calculation ------------------------------------------------
#' @rdname WildPigABM
grossMargin <- function(price,damage,map_height,map_width,pigCount,adjYield,varCost,...){
  (price * ((1 - (
    array(data = damage, c(map_height, map_width)) * pigCount
  )) * adjYield)) -
    array(data = varCost, c(map_height, map_width))
}

#' @rdname WildPigABM
grossMarginWP <- function(allowed, crop_price, crop_damage, map_height, map_width, adjusted_crop_yield, absence, pig_price, pig_var_cost,...){
  (allowed * crop_price * array(data = crop_damage, c(map_height, map_width)) * adjusted_crop_yield * absence + #Damage Avoided, Corn, Per Pig
     allowed * pig_price * absence  - # Per Pig Removed Revenue from offering Pig Hunts (Could add monetized non-pecuniary benefits here)
     array(data = pig_var_cost, c(map_height, map_width))
  )
}
## rowBindGM() - put gross margins together --------------------------------------
#' @rdname WildPigABM
rowBindGM <- function(total_patches, gmCorn, gmSoy, gmCRP, gmCornFee, gmCornFreePres,
                      gmCornFreeNotPres, gmCornPayPaid, gmSoyFee, gmSoyFreePres, 
                      gmSoyFreeNotPres, gmSoyPayPaid, gmCRPFee, gmCRPFreePres,
                      gmCRPFreeNotPres, gmCRPPayPaid, ...){
  cbind(
    array(data = as.numeric(gmCorn[, ]), c(1, total_patches)),
    array(data = as.numeric(gmSoy[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCRP[, ]), c(1, total_patches)),
    #ON CORN
    array(data = as.numeric(gmCornFee[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCornFreePres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCornFreeNotPres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCornPayPaid[, ]), c(1, total_patches)),
    #ON SOY
    array(data = as.numeric(gmSoyFee[, ]), c(1, total_patches)),
    array(data = as.numeric(gmSoyFreePres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmSoyFreeNotPres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmSoyPayPaid[, ]), c(1, total_patches)),
    #ON CRP
    array(data = as.numeric(gmCRPFee[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCRPFreePres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCRPFreeNotPres[, ]), c(1, total_patches)),
    array(data = as.numeric(gmCRPPayPaid[, ]), c(1, total_patches))
  )
}
## repeatGMinitHH() - repeat gross margin row to create a matrix that has init_hh rows--------------------------
#' @rdname WildPigABM
repeatGMinitHH <- function(boundGMdat,init_hh,num_choice,total_patches,...){
  array(data =  repColrepRow::repRow(boundGMdat[, ], init_hh),
        c(init_hh, num_choice * total_patches))
}
## resourceConstraintRow - Function to make resource constraints into the format needed for optimization ----------------------------
#' @rdname WildPigABM
resourceConstraintRow <- function(total_patches,
                                  corn, 
                                  soy, 
                                  CRP, 
                                  Fee, 
                                  free_pres, 
                                  Paid){
  cbind(
    array(data = corn, c(1, total_patches)),
    array(data = soy, c(1, total_patches)),
    array(data = CRP, c(1, total_patches)),
    #ON CORN
    array(data = Fee, c(1, total_patches)),
    array(data = free_pres, c(1, total_patches)),
    array(data = Paid, c(1, total_patches)),
    #ON SOYBEANS
    array(data = Fee, c(1, total_patches)),
    array(data = free_pres, c(1, total_patches)),
    array(data = Paid, c(1, total_patches)),
    #ON CRP
    array(data = Fee, c(1, total_patches)),
    array(data = free_pres, c(1, total_patches)),
    array(data = Paid, c(1, total_patches))
  )
}

# bindTechR() bind tech coeff matrix ---------------------
#' @rdname WildPigABM
bindTechR <- function(multiYearLand, verboseR, varCost_offFarm,
                      vcRow, t_offfarm, tRow, restrictionCorn,
                      restrictionSoy, restrictionCRP, ownerRepk,
                      total_patches, num_choice,EGM_offFarmV,ownerGM,index,j,t,...){
  obj0 <-
    c(EGM_offFarmV[j], ownerGM[j,])
  mat0 <- rbind(
    c(varCost_offFarm, vcRow),
    c(t_offfarm, tRow),
    c(0, restrictionCorn),
    c(0, restrictionSoy),
    c(0, restrictionCRP),
    c(0, ownerRepk[j, ])
  )
  if (verboseR == TRUE) {print(paste("mat0 len", dim(mat0)))}
  
  if (multiYearLand == TRUE){
    zeroBlock5 <-
      matrix(
        data = 0,
        nrow = 5,
        ncol = (1 + total_patches * num_choice)
      )
    zeroBlock6 <-
      matrix(
        data = 0,
        nrow = 6,
        ncol = (1 + total_patches * num_choice)
      )
    mat1 <- rbind(mat0,
                  obj0, zeroBlock5)
    mat2 <- rbind(zeroBlock6,
                  mat0)
    mat3 <- cbind(mat1, mat2)
    }
    if (verboseR == TRUE) {print(paste("mat3 dim", dim(mat3)))}
  else{
    mat3 <- mat0
    if (verboseR == TRUE) {print(paste("mat3 dim", dim(mat3)))}
  }
  mat3[, as.logical(index[j, ]), drop = FALSE]
  }
# bindObjR() bind the objective statemnts-----------
#' @rdname WildPigABM
bindObjR <- function(multiYearLand, verboseR,EGM_offFarmV,
                       ownerGM,index,j,...){
    obj0 <-
      c(EGM_offFarmV[j], ownerGM[j,])
    if (verboseR == TRUE) {print(paste("obj0 dim", length(obj0)))}
    if (multiYearLand == TRUE){
      obj3 <- c(obj0, obj0)
      if (verboseR == TRUE) {print(paste("obj3 dim", length(obj3)))}
      }
    else{
      obj3 <- obj0
      if (verboseR == TRUE) {print(paste("obj3 dim", length(obj3)))}
    }
    obj4 <- matrix(data=obj3,nrow=1)
    obj6 <- c(
    obj4[, as.logical(index[j,]), drop = FALSE])
    if (verboseR == TRUE) {print(paste("obj6 dim", length(obj6)))}
    return(obj6)
  }
  
# bindDirR() - bind direction indicators for constraints together----------
#' @rdname WildPigABM
bindDirR <- function(multiYearLand, verboseR,...){
    dir0 <- c('<=', '<=', '<=', '<=', '<=', '<=')
    if (verboseR == TRUE) {print(paste("dir0 dim", dim(dir0)))}
    if (multiYearLand == TRUE){
      c(dir0, dir0)
    }
    else{
      return(dir0)
    }
  }
# bindTypeR() - bind types of variables together--------------------
#' @rdname WildPigABM
bindTypeR <- function(multiYearLand, verboseR,total_patches, index=index,j,cont,...){
    ifelse(cont == TRUE,
           (types0 =
             c('C',
               rep('C', len = total_patches * 3),
               rep('C', len = total_patches * 12))),
           (types0 =
             c('I',
               rep('B', len = total_patches * 3),
               rep('I', len = total_patches * 12)))
           )
  
    if (verboseR == TRUE) {print(paste("types0 dim", dim(types0)))}
    if (multiYearLand == TRUE){
      types1 <- rep(types0, times = 2)
      
    }
    else{
      types1 <- types0
    }
    types2 <- matrix(data=types1,nrow = 1)
    types3 <- 
      c(types2[, as.logical(index[j,]), drop = FALSE])
    if (verboseR == TRUE) {print(paste("types3 dim", length(types3)))}
    return(types3)
  }
# bindRHSR() - bind RHS together ---------------------
#' @rdname WildPigABM
bindRHSR <- function(multiYearLand, verboseR,wealthi,ownerSum,j,t,...){
    wealthj <- wealthi[j, , t]
    land <- as.numeric(ownerSum[j])
    rhs0 <-
      c(wealthj, 365, rep(0, len = 3), land)
    if (multiYearLand == TRUE){
      c(rhs0, rhs0)
    }
    else{
      return(rhs0)
    }
  }

# calculate parcel net income--------------------------
#' @rdname WildPigABM
calcParcelNI <- function(unit_mat,null_mat,
                           ma_CORN, ma_SOY, ma_CRP,
                           P_corn, P_soy, P_CRP,
                           Yield_corn, Yield_soy, Yield_CRP,
                           tempCornDam, tempSoyDam,
                           varCost_corn, varCost_soy, verCost_CRP,
                          ma_FEEPAYINGCORN, ma_FEEPAYINGSOY,
                          ma_FEEPAYINGCRP, ma_UNPAIDPRESCORN,
                          ma_UNPAIDPRESSOY,ma_UNPAIDPRESCRP,
                          ma_UNPAIDNOTCORN, ma_UNPAIDNOTSOY,
                          ma_UNPAIDNOTCRP, ma_PAIDREMOVALCORN,
                          ma_PAIDREMOVALSOY,ma_PAIDREMOVALCRP,
                          P_feePaying, varCost_Fee,varCost_free,...){
  RNetLogo::NLCommand('calculateParcelNI')
  RNetLogo::NLGetPatches('parcel_NI', patchset = 'patches', as.matrix = TRUE,
                         as.data.frame = FALSE)
    # Move this function back to NetLogo
    # ma_CORN * (P_corn * Yield_corn * (unit_mat - tempCornDam) - varCost_corn) +
    # ma_SOY * (P_soy * Yield_soy * (unit_mat - tempSoyDam) - varCost_soy) +
    # ma_CRP * (P_CRP * Yield_CRP - verCost_CRP) +
    # ma_FEEPAYINGCORN  * (P_feePaying + P_corn * Yield_corn * tempCornDam - varCost_Fee) +
    # ma_FEEPAYINGSOY   * (P_feePaying + P_soy * Yield_soy * tempSoyDam - varCost_Fee) +
    # ma_FEEPAYINGCRP   * (P_feePaying - varCost_Fee) +
    # ma_UNPAIDPRESCORN * (P_corn * Yield_corn *  tempCornDam - varCost_free) +
    # ma_UNPAIDPRESSOY  * (P_soy * Yield_soy * tempSoyDam - varCost_free) +
    # ma_UNPAIDPRESCRP  * (null_mat - varCost_free) +
    # ma_UNPAIDNOTCORN  * (P_corn * Yield_corn *  tempCornDam  - varCost_free) +
    # ma_UNPAIDNOTSOY   * (P_soy * Yield_soy * tempSoyDam - varCost_free) +
    # ma_UNPAIDNOTCRP   * (null_mat - varCost_free) +
    # ma_PAIDREMOVALCORN * (P_corn * Yield_corn *  tempCornDam  - varCost_Paid) +
    # ma_PAIDREMOVALSOY * (P_soy * Yield_soy * tempSoyDam - varCost_Paid) +
    # ma_PAIDREMOVALCRP * (null_mat - varCost_Paid)
}
#' @keywords wild pigs
#' @rdname WildPigABM
pushLUtoNL <- function(t, total_patches,num_choice,LPresultsT) {
  space1 <- seq(2,total_patches*num_choice+1,total_patches)
  ma_CORN <-
    array(data = as.numeric(lapply(space1[1]:space1[1]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        1
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches('a_CORN', ma_CORN[, ])
  ma_SOY <-
    array(data = as.numeric(lapply(space1[2]:space1[2]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        1
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_SOY", ma_SOY[, ])
  ma_CRP <-
    array(data = as.numeric(lapply(space1[3]:space1[3]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        1
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_CRP", ma_CRP[, ])
  #ON CORN
  ma_FEEPAYINGCORN <-
    array(data = as.numeric(lapply(space1[4]:space1[4]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_FEEPAYINGCORN", ma_FEEPAYINGCORN[, ])
  ma_UNPAIDPRESCORN <-
    array(data = as.numeric(lapply(space1[5]:space1[5]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_UNPAIDPRESCORN", ma_UNPAIDPRESCORN[, ])
  
  ma_PAIDREMOVALCORN <-
    array(data = as.numeric(lapply(space1[6]:space1[6]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_PAIDREMOVALCORN", ma_PAIDREMOVALCORN[, ])
  #ON SOY
  ma_FEEPAYINGSOY <-
    array(data = as.numeric(lapply(space1[7]:space1[7]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_FEEPAYINGSOY", ma_FEEPAYINGSOY[, ])
  ma_UNPAIDPRESSOY <-
    array(data = as.numeric(lapply(space1[8]:space1[8]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_UNPAIDPRESSOY", ma_UNPAIDPRESSOY[, ])
  
  ma_PAIDREMOVALSOY <-
    array(data = as.numeric(lapply(space1[9]:space1[9]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_PAIDREMOVALSOY", ma_PAIDREMOVALSOY[, ])
  #on CRP
  ma_FEEPAYINGCRP <-
    array(data = as.numeric(lapply(space1[10]:space1[10]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_FEEPAYINGCRP", ma_FEEPAYINGCRP[, ])
  ma_UNPAIDPRESCRP <-
    array(data = as.numeric(lapply(space1[11]:space1[11]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_UNPAIDPRESCRP", ma_UNPAIDPRESCRP[, ])
  
  ma_PAIDREMOVALCRP <-
    array(data = as.numeric(lapply(space1[12]:space1[12]+total_patches-1, function(x)
      if (any(LPresultsT[,x , t] != 0, na.rm = TRUE))
        max(LPresultsT[,x , t], na.rm = TRUE)
      else
        0)), c(map_height, map_width))
  RNetLogo::NLSetPatches("a_PAIDREMOVALCRP", ma_PAIDREMOVALCRP[, ])
  if (verboseR == TRUE) {print(paste("LU pushed in period ", t))}
  return(list(     ma_FEEPAYINGCORN, ma_FEEPAYINGSOY,
                   ma_FEEPAYINGCRP, ma_UNPAIDPRESCORN,
                   ma_UNPAIDPRESSOY,ma_UNPAIDPRESCRP,
                   ma_PAIDREMOVALCORN,
                   ma_PAIDREMOVALSOY,ma_PAIDREMOVALCRP))
}




