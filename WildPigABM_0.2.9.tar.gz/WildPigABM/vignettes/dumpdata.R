p <-
structure(list(Year = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 
1, 2, 3, 4, 5, 6, 7, 8, 9, 10), Population = c(75, 81, 109, 180, 
338, 669, 1337, 1337, 1337, 1337, 1337, 25, 66, 115, 179, 299, 
575, 1099, 1020, 971, 937, 911), group = structure(c(1L, 1L, 
1L, 1L, 1L, 1L, 1L, 1L, 1L, 1L, 1L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 
2L, 2L, 2L, 2L), class = "factor", .Label = c("Sows", "Boars"
))), .Names = c("Year", "Population", "group"), row.names = c(NA, 
22L), class = "data.frame")
