                               
res_SP_R_15 <- doOne(typeDecision = "SP",generic_removal_price = -15.00,
      outlook = "random", data	=	 BaseLine, gui = FALSE)
res_LO_R_15 <- doOne(typeDecision = "LO",generic_removal_price = -15.00,
      outlook = "random",data	=	 BaseLine, gui = FALSE)
res_SP_R_01 <- doOne(typeDecision = "SP",generic_removal_price = -0.01,
      outlook = "random",data	=	 BaseLine, gui = FALSE)
res_LO_R_01 <- doOne(typeDecision = "LO",generic_removal_price= -0.01,
      outlook = "random", data	=	 BaseLine, gui = FALSE)
res_SP_P_15 <- doOne(typeDecision = "SP",generic_removal_price= -15.00,
      outlook = "positive", data	=	 BaseLine, gui = FALSE)
res_LO_P_15 <- doOne(typeDecision = "LO",generic_removal_price = -15.00,
      outlook = "positive", data	=	 BaseLine, gui = FALSE)
res_SP_P_01 <- doOne(typeDecision= "SP",generic_removal_price= -0.01,
      outlook = "positive",data	=	 BaseLine, gui = FALSE)
res_LO_P_01 <-  doOne(typeDecision = "LO",generic_removal_price = -0.01,
      outlook = "positive", data	=	 BaseLine, gui = FALSE)
res_SP_N_15 <- doOne(typeDecision = "SP",generic_removal_price = -15.00,
      outlook = "neutral", data	=	 BaseLine, gui = FALSE)
res_LO_N_15 <- doOne(typeDecision = "LO",generic_removal_price = -15.00,
      outlook = "neutral", data	=	 BaseLine, gui = FALSE)
res_SP_N_01 <- doOne(typeDecision = "SP",generic_removal_price = -0.01,
      outlook = "neutral", data	=	 BaseLine, gui = FALSE)
res_LO_N_01 <- doOne(typeDecision = "LO",generic_removal_price = -0.01,
      outlook = "neutral", data	=	 BaseLine, gui = FALSE)
res_SP_Neg_15 <- doOne(typeDecision = "SP",generic_removal_price=-15.00, 
      outlook = "negative", data	=	 BaseLine, gui = FALSE)
res_LO_Neg_15 <- doOne(typeDecision = "LO",generic_removal_price = -15.00,
      outlook = "negative", data	=	 BaseLine, gui = FALSE)
res_SP_Neg_01 <- doOne(typeDecision = "SP",generic_removal_price = -0.01,
      outlook = "negative", data	=	 BaseLine, gui = FALSE)
res_LO_Neg_01 <- doOne(typeDecision = "LO",generic_removal_price = -0.01 ,
      outlook = "negative", data	=	 BaseLine, gui = FALSE)
res_SP_M_15 <- doOne(typeDecision = "SP",generic_removal_price = -15.00,
      outlook = "myopic", data	=	 BaseLine, gui = FALSE)
res_LO_M_15 <- doOne(typeDecision = "LO",generic_removal_price = -15.00,
      outlook = "myopic", data	=	 BaseLine, gui = FALSE)
res_SP_M_01 <- doOne(typeDecision = "SP",generic_removal_price = -0.01,
      outlook = "myopic", data	=	 BaseLine, gui = FALSE)
res_LO_M_01 <- doOne(typeDecision = "LO",generic_removal_price = "-0.01",
      outlook = "myopic", data	=	 BaseLine, gui = FALSE)

















